package com.zahid.myroutine;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.StrikethroughSpan;
import android.view.View;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class RoutineWidget extends AppWidgetProvider {
    static final String TOGGLE = "com.zahid.myroutine.TOGGLE";
    static final String[] NAMES = {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
    static final String[][][] CLASSES = {
        {{"8:30","Web Engineering"},{"9:30","Data Structure & Algorithm"},{"11:30","Operating System Lab"},{"1:30","Computer Org & Assembly"},{"2:30","Design & Analysis of Algo"}},
        {{"8:30","DSA Lab"},{"1:30","Computer Org & Assembly"},{"2:30","Agile Software Dev"}},
        {{"9:30","Operating System"},{"10:30","Data Structure & Algorithm"},{"1:30","Design & Analysis of Algo"},{"2:30","COA Lab"}},
        {{"11:30","Operating System"},{"12:30","Web Engineering Lab"},{"2:30","Agile Software Dev"},{"3:30","Design & Analysis of Algo"}},
        {{"11:30","Web Engineering"},{"12:30","Data Structure & Algorithm"},{"2:30","Agile Software Dev Lab"}},
        {}, {}
    };
    static final String[] STUDY = {"1 hour","Light / recovery","1 hour","1 hour","1 hour","3 hours","3 hours"};
    static final String[] WORKOUT = {"40 min","Rest","Rest","40 min","Optional walk","60 min","60 min"};
    static final int[] ROWS = {R.id.r0,R.id.r1,R.id.r2,R.id.r3,R.id.r4,R.id.r5,R.id.r6,R.id.r7};

    static int today() { return (Calendar.getInstance().get(Calendar.DAY_OF_WEEK) + 5) % 7; }

    static String dateKey() {
        Calendar c = Calendar.getInstance();
        return String.format(Locale.US, "d-%d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    static List<String> items(int d) {
        List<String> l = new ArrayList<>();
        for (String[] c : CLASSES[d]) l.add(c[0] + "  " + c[1]);
        if (d != 6) l.add("5:45 PM  Work shift");
        l.add("Study · " + STUDY[d]);
        l.add("Workout · " + WORKOUT[d]);
        return l;
    }

    static Set<String> done(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences("routine", Context.MODE_PRIVATE);
        return new HashSet<>(p.getStringSet(dateKey(), new HashSet<>()));
    }

    static void updateAll(Context ctx) {
        AppWidgetManager m = AppWidgetManager.getInstance(ctx);
        int[] ids = m.getAppWidgetIds(new ComponentName(ctx, RoutineWidget.class));
        for (int id : ids) m.updateAppWidget(id, build(ctx));
        scheduleMidnight(ctx);
    }

    static RemoteViews build(Context ctx) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_layout);
        int d = today();
        List<String> it = items(d);
        Set<String> done = done(ctx);
        int n = 0;
        for (int i = 0; i < ROWS.length; i++) {
            if (i >= it.size()) { v.setViewVisibility(ROWS[i], View.GONE); continue; }
            boolean ok = done.contains(String.valueOf(i));
            if (ok) n++;
            String t = (ok ? "✅  " : "⬜  ") + it.get(i);
            SpannableString s = new SpannableString(t);
            if (ok) s.setSpan(new StrikethroughSpan(), 3, t.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            v.setViewVisibility(ROWS[i], View.VISIBLE);
            v.setTextViewText(ROWS[i], s);
            v.setTextColor(ROWS[i], ok ? 0xFF7F8FA6 : 0xFFEDF4FF);
            Intent t2 = new Intent(ctx, RoutineWidget.class).setAction(TOGGLE).putExtra("i", i);
            v.setOnClickPendingIntent(ROWS[i], PendingIntent.getBroadcast(ctx, 100 + i, t2,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        }
        int pct = it.isEmpty() ? 0 : n * 100 / it.size();
        v.setTextViewText(R.id.title, NAMES[d] + " routine");
        v.setTextViewText(R.id.sub, n + "/" + it.size() + " done · " + pct + "%" + (pct == 100 ? "  🎉" : ""));
        v.setProgressBar(R.id.prog, 100, pct, false);
        Intent open = new Intent(ctx, MainActivity.class);
        v.setOnClickPendingIntent(R.id.header, PendingIntent.getActivity(ctx, 1, open, PendingIntent.FLAG_IMMUTABLE));
        return v;
    }

    static void scheduleMidnight(Context ctx) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, 1);
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 5);
        Intent i = new Intent(ctx, RoutineWidget.class).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 7, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.set(AlarmManager.RTC, c.getTimeInMillis(), pi);
    }

    @Override public void onUpdate(Context ctx, AppWidgetManager m, int[] ids) { updateAll(ctx); }

    @Override public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        String a = intent.getAction();
        if (TOGGLE.equals(a)) {
            String k = String.valueOf(intent.getIntExtra("i", -1));
            Set<String> s = done(ctx);
            if (!s.remove(k)) s.add(k);
            ctx.getSharedPreferences("routine", Context.MODE_PRIVATE).edit().putStringSet(dateKey(), s).apply();
            updateAll(ctx);
        } else if (AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(a)) {
            updateAll(ctx);
        }
    }
}
