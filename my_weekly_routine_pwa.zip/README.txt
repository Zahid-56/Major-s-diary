MY WEEKLY ROUTINE — PRIVATE PERSONAL PWA

This folder is a Progressive Web App package. It can be installed on your Android home screen after hosting over HTTPS.
The files do not contain account sign-in or analytics. Anyone with the published URL can access the planner, so don't publish sensitive data.

FREE QUICK SETUP WITH GITHUB PAGES:
1. Sign in/create a GitHub account and create a new repository (e.g. my-weekly-routine).
2. Upload all 4 files from this folder into the repository root: index.html, manifest.webmanifest, sw.js, icon.svg.
3. Repository Settings > Pages > Deploy from a branch > select main and /(root) > Save.
4. Wait for GitHub Pages to publish, then open the resulting https://...github.io/... link on Android Chrome.
5. Chrome menu (⋮) > Install app (or Add to Home screen) > Install.
6. Open the new My Routine app icon from your home screen.

Updates: after changing site files, the service worker cache name may need to be incremented in sw.js (my-routine-v1 -> v2); then refresh/reopen.

NOTE: This is app-style full screen PWA, not a resizable Android widget. A true Android home-screen widget needs native Android/third-party widget tooling.
